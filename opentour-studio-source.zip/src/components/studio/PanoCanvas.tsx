import { useCallback, useEffect, useRef, useState } from "react";
import { DoorOpen, Info, MoveRight, Minus, Plus, Crosshair } from "lucide-react";
import type { Hotspot, Scene } from "@/types/tour";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const MIN_ZOOM = 0.6;
const MAX_ZOOM = 3;
const BASE_FOV = 110;

const icons = { door: DoorOpen, info: Info, arrow: MoveRight } as const;

interface Props {
  scene: Scene | null;
  imageUrl: string;
  mode: "editor" | "preview";
  placing: boolean;
  selectedHotspotId: string | null;
  onSelectHotspot: (id: string | null) => void;
  onAddHotspot: (pitch: number, yaw: number) => void;
  onMoveHotspot: (id: string, pitch: number, yaw: number) => void;
  onNavigate: (sceneId: string) => void;
  onZoomChange: (zoom: number) => void;
}

export function PanoCanvas({
  scene,
  imageUrl,
  mode,
  placing,
  selectedHotspotId,
  onSelectHotspot,
  onAddHotspot,
  onMoveHotspot,
  onNavigate,
  onZoomChange,
}: Props) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [size, setSize] = useState({ w: 1, h: 1 });
  const [view, setView] = useState({ yaw: 0, pitch: 0 });
  const [zoom, setZoom] = useState(scene?.defaultZoom ?? 1);
  const [toast, setToast] = useState<string | null>(null);
  const dragRef = useRef<{ x: number; y: number; hotspotId?: string | undefined } | null>(null);

  useEffect(() => {
    setView({ yaw: 0, pitch: 0 });
    setZoom(scene?.defaultZoom ?? 1);
  }, [scene?.id, scene?.defaultZoom]);

  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const update = () => setSize({ w: el.clientWidth || 1, h: el.clientHeight || 1 });
    update();
    const observer = new ResizeObserver(update);
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  const fov = BASE_FOV / zoom;
  const vfov = fov * (size.h / size.w);

  const applyZoom = useCallback(
    (next: number) => {
      const clamped = Math.max(MIN_ZOOM, Math.min(MAX_ZOOM, next));
      setZoom(clamped);
      onZoomChange(Number(clamped.toFixed(2)));
    },
    [onZoomChange],
  );

  const zoomRef = useRef(applyZoom);
  zoomRef.current = applyZoom;
  const currentZoom = useRef(zoom);
  currentZoom.current = zoom;

  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const onWheel = (event: WheelEvent) => {
      event.preventDefault();
      const dy = event.deltaY * (event.deltaMode === 1 ? 16 : event.deltaMode === 2 ? 100 : 1);
      zoomRef.current(currentZoom.current * Math.exp(-dy * 0.0015));
    };
    el.addEventListener("wheel", onWheel, { passive: false });
    return () => el.removeEventListener("wheel", onWheel);
  }, []);

  const toXY = (hotspot: Hotspot) => ({
    x: size.w / 2 + ((hotspot.yaw - view.yaw) / fov) * size.w,
    y: size.h / 2 - ((hotspot.pitch - view.pitch) / vfov) * size.h,
  });

  const toAngles = (clientX: number, clientY: number) => {
    const rect = containerRef.current!.getBoundingClientRect();
    const px = clientX - rect.left;
    const py = clientY - rect.top;
    return {
      yaw: clamp(view.yaw + ((px - size.w / 2) / size.w) * fov, -180, 180),
      pitch: clamp(view.pitch - ((py - size.h / 2) / size.h) * vfov, -89, 89),
    };
  };

  const handlePointerDown = (event: React.PointerEvent, hotspotId?: string) => {
    if (hotspotId && mode === "preview") return;
    dragRef.current = { x: event.clientX, y: event.clientY, hotspotId };
    (event.currentTarget as HTMLElement).setPointerCapture?.(event.pointerId);
  };

  const handlePointerMove = (event: React.PointerEvent) => {
    const drag = dragRef.current;
    if (!drag) return;
    const dx = event.clientX - drag.x;
    const dy = event.clientY - drag.y;
    if (drag.hotspotId) {
      const angles = toAngles(event.clientX, event.clientY);
      onMoveHotspot(drag.hotspotId, Number(angles.pitch.toFixed(1)), Number(angles.yaw.toFixed(1)));
    } else {
      setView((prev) => ({
        yaw: clamp(prev.yaw - (dx / size.w) * fov, -180, 180),
        pitch: clamp(prev.pitch + (dy / size.h) * vfov, -80, 80),
      }));
    }
    dragRef.current = { ...drag, x: event.clientX, y: event.clientY };
  };

  const handlePointerUp = () => {
    dragRef.current = null;
  };

  const handleCanvasClick = (event: React.MouseEvent) => {
    if (mode !== "editor" || !placing || !scene) return;
    const { pitch, yaw } = toAngles(event.clientX, event.clientY);
    onAddHotspot(Number(pitch.toFixed(1)), Number(yaw.toFixed(1)));
  };

  const handleHotspotClick = (hotspot: Hotspot) => {
    if (mode === "editor") {
      onSelectHotspot(hotspot.id);
      return;
    }
    if ((hotspot.type === "door" || hotspot.type === "arrow") && hotspot.targetSceneId) {
      onNavigate(hotspot.targetSceneId);
      return;
    }
    setToast(hotspot.tooltip || "No information");
    window.setTimeout(() => setToast(null), 2600);
  };

  const bgW = (size.w * 360) / fov;
  const bgH = (size.h * 180) / vfov;

  return (
    <div className="relative flex-1 overflow-hidden bg-background">
      <div
        ref={containerRef}
        onPointerDown={(e) => handlePointerDown(e)}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onPointerLeave={handlePointerUp}
        onClick={handleCanvasClick}
        className={cn(
          "absolute inset-0 touch-none select-none",
          placing && mode === "editor" ? "cursor-crosshair" : "cursor-grab active:cursor-grabbing",
        )}
        style={
          imageUrl
            ? {
                backgroundImage: `url(${JSON.stringify(imageUrl).slice(1, -1)})`,
                backgroundRepeat: "no-repeat",
                backgroundSize: `${bgW}px ${bgH}px`,
                backgroundPosition: `${size.w / 2 - ((view.yaw + 180) / 360) * bgW}px ${
                  size.h / 2 - ((90 - view.pitch) / 180) * bgH
                }px`,
              }
            : undefined
        }
      >
        {!scene && (
          <div className="flex h-full items-center justify-center text-sm text-muted-foreground">
            Add a scene from the Scenes panel to start building your tour.
          </div>
        )}
        {scene && !imageUrl && (
          <div className="flex h-full items-center justify-center text-sm text-muted-foreground">
            Panorama image is unavailable for this scene.
          </div>
        )}

        {scene?.hotspots.map((hotspot) => {
          const { x, y } = toXY(hotspot);
          if (x < -80 || y < -80 || x > size.w + 80 || y > size.h + 80) return null;
          const Icon = icons[hotspot.type];
          const selected = hotspot.id === selectedHotspotId && mode === "editor";
          return (
            <button
              key={hotspot.id}
              type="button"
              onPointerDown={(e) => {
                e.stopPropagation();
                handlePointerDown(e, hotspot.id);
              }}
              onPointerMove={(e) => e.stopPropagation()}
              onClick={(e) => {
                e.stopPropagation();
                handleHotspotClick(hotspot);
              }}
              style={{ left: x, top: y }}
              className={cn(
                "absolute flex -translate-x-1/2 -translate-y-1/2 items-center gap-1.5 rounded-full border px-2.5 py-1.5 text-xs font-medium backdrop-blur transition-colors",
                selected
                  ? "border-primary bg-primary text-primary-foreground shadow-[0_0_0_4px_oklch(0.585_0.216_276_/_25%)]"
                  : "border-primary/50 bg-card/80 text-foreground hover:border-primary hover:bg-primary/80 hover:text-primary-foreground",
              )}
            >
              <Icon className="h-3.5 w-3.5" />
              <span className="max-w-32 truncate">{hotspot.tooltip || hotspot.type}</span>
            </button>
          );
        })}
      </div>

      {placing && mode === "editor" && (
        <div className="pointer-events-none absolute left-1/2 top-4 flex -translate-x-1/2 items-center gap-2 rounded-full border border-primary/60 bg-card/90 px-3 py-1.5 text-xs text-foreground">
          <Crosshair className="h-3.5 w-3.5 text-primary" />
          Click on the panorama to place the hotspot
        </div>
      )}

      {toast && (
        <div className="pointer-events-none absolute bottom-20 left-1/2 max-w-sm -translate-x-1/2 rounded-lg border border-border bg-card/95 px-4 py-2.5 text-sm text-foreground shadow-lg">
          {toast}
        </div>
      )}

      <div className="absolute bottom-4 right-4 flex flex-col gap-1 rounded-lg border border-border bg-card/90 p-1 backdrop-blur">
        <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => applyZoom(zoom * 1.2)}>
          <Plus className="h-4 w-4" />
        </Button>
        <div className="px-1 text-center text-[10px] tabular-nums text-muted-foreground">
          {zoom.toFixed(1)}x
        </div>
        <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => applyZoom(zoom / 1.2)}>
          <Minus className="h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}

function clamp(value: number, min: number, max: number) {
  return Math.max(min, Math.min(max, value));
}